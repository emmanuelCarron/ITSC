def suma(arreglo)
    return sum(arreglo)
