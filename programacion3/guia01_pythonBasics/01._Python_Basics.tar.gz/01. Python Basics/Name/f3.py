"""
Este archivo no sirve para nada.
"""
import f1

print(vars())
if f1.is_monday():
    print('Hoy es lunes!')
else:
    print('Hoy martes, miercoles, jueves, viernes, sábado o domingo')
