print('Comenzando lectura del módulo', __name__)

if __name__ == '__main__':
    print('Ejecutando el módulo', __file__)
