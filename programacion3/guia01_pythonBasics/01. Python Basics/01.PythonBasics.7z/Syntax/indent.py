print('En python es muy importante el nivel de indentación')
# print('Esta línea está bien?')
print('Esta línea está bien!')

"""
    La linea presenta un espacio en blanco con lo cual, da un error
    de indentación.-
"""
