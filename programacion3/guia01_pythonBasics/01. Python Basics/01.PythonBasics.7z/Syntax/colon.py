def suma(arreglo):
    return sum(arreglo)

"""
    La funcion no tenia los dos puntos al final de la linea del def.-
"""
